package nl.nielskonings.kompas;

import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Teksten en keuzes voor de widget. Alleen Java en org.json, zodat het los te testen is. */
public final class KompasWidgetText {
    private static final Locale NL = new Locale("nl", "NL");
    private KompasWidgetText() {}

    public static final class Result {
        public String over = "Kompas", title = "Open Kompas", sub = "", water = "0 van 2.000 ml", next = "";
        public int progress = 0;
        public long refresh = 0;
    }

    public static final class Now {
        public String title = "Wat doe je nu?", sub = "Tik erop, dan komt het in je agenda", btn = "", mode = "", cat = "", color = "#3A4255";
        public long refresh = 0;
    }

    public static final class Habit {
        public String id = "", icon = "", name = "", color = "#8B7CF6", sub = "", mode = "tap", btn = "";
        public boolean done = false;
    }

    static String hm(long t) { return new SimpleDateFormat("HH:mm", NL).format(new Date(t)); }

    static String dur(long ms) {
        long m = Math.max(1, Math.round(ms / 60000.0));
        if (m < 60) return m + " min";
        long h = m / 60, r = m % 60;
        return r == 0 ? h + " u" : h + " u " + r;
    }

    static String dayWord(long t, long today0) {
        if (t >= today0 && t < today0 + 86400000L) return "";
        if (t >= today0 + 86400000L && t < today0 + 2 * 86400000L) return "morgen";
        return new SimpleDateFormat("EEEE", NL).format(new Date(t));
    }

    static String cap(String s) { return s == null || s.isEmpty() ? "" : s.substring(0, 1).toUpperCase(NL) + s.substring(1); }

    static String nf(int n) { return String.format(NL, "%,d", n); }

    static int hourOf(long t) { Calendar c = Calendar.getInstance(); c.setTimeInMillis(t); return c.get(Calendar.HOUR_OF_DAY); }

    static int pendingWater(String pendingJson, long today0) {
        int sum = 0;
        try {
            JSONArray pend = new JSONArray(pendingJson == null ? "[]" : pendingJson);
            for (int i = 0; i < pend.length(); i++) {
                JSONObject o = pend.getJSONObject(i);
                String t = o.optString("t", "water");
                if (!"water".equals(t)) continue;
                if (o.optLong("ts", 0) >= today0) sum += o.optInt("ml", 0);
            }
        } catch (Exception e) {
            // niets
        }
        return sum;
    }

    static JSONObject obj(String json) {
        try { return new JSONObject(json == null || json.isEmpty() ? "{}" : json); } catch (Exception e) { return new JSONObject(); }
    }

    /** Kleine widget: de eerstvolgende afspraak en je water. */
    public static Result compute(String dataJson, String pendingJson, long now, long today0, String todayStr) throws Exception {
        Result r = new Result();
        JSONObject d = obj(dataJson);
        long next = now + 3600000L;
        long midnight = today0 + 86400000L;
        if (midnight < next) next = midnight + 60000L;
        JSONArray items = d.optJSONArray("items");
        JSONObject cur = null, nxt = null;
        if (items != null) {
            for (int i = 0; i < items.length(); i++) {
                JSONObject it = items.getJSONObject(i);
                long s = it.optLong("s"), e = it.optLong("e"), l = it.optLong("l", 0);
                if (e <= now) continue;
                if (s <= now && cur == null) cur = it;
                else if (s > now && nxt == null) nxt = it;
                if (s > now && s < next) next = s;
                if (e > now && e < next) next = e;
                if (l > now && l < next) next = l;
            }
        }
        if (cur != null) {
            long e = cur.optLong("e");
            r.over = "Nu, nog " + dur(e - now);
            r.title = cur.optString("t", "");
            String loc = cur.optString("loc", "");
            r.sub = "Tot " + hm(e) + (loc.isEmpty() ? "" : ", " + loc);
            if (nxt != null && nxt.optLong("s") - e < 6 * 3600000L) r.sub = r.sub + ", daarna " + hm(nxt.optLong("s"));
            r.next = "Nu: " + r.title + ", tot " + hm(e);
            long q = now + 15 * 60000L;
            if (q < next) next = q;
        } else if (nxt != null) {
            long s = nxt.optLong("s"), l = nxt.optLong("l", 0);
            String dw = dayWord(s, today0);
            String when = dw.isEmpty() ? "om " + hm(s) : dw + " om " + hm(s);
            if (l > now) {
                String lw = dayWord(l, today0);
                r.over = "Vertrek " + (lw.isEmpty() ? "om " : lw + " om ") + hm(l);
                if (lw.isEmpty() && l - now < 12 * 3600000L) r.over = r.over + ", over " + dur(l - now);
                long q = now + 15 * 60000L;
                if (l - now < 3 * 3600000L && q < next) next = q;
            } else {
                r.over = dw.isEmpty() ? "Straks om " + hm(s) : cap(dw) + " om " + hm(s);
            }
            r.title = nxt.optString("t", "");
            String loc = nxt.optString("loc", "");
            r.sub = hm(s) + " tot " + hm(nxt.optLong("e")) + (loc.isEmpty() ? "" : ", " + loc);
            r.next = (l > now && dayWord(l, today0).isEmpty()) ? "Vertrek om " + hm(l) + " voor " + r.title : "Straks: " + r.title + ", " + when;
        } else {
            r.over = "Vandaag";
            r.title = "Niets meer gepland";
            r.sub = "Geniet van je vrije tijd";
            r.next = "Geen afspraken meer vandaag";
        }
        JSONObject w = d.optJSONObject("water");
        int goal = w == null ? 2000 : Math.max(1, w.optInt("goal", 2000));
        int base = (w != null && todayStr.equals(w.optString("date", ""))) ? w.optInt("total", 0) : 0;
        int total = base + pendingWater(pendingJson, today0);
        r.water = nf(total) + " van " + nf(goal) + " ml";
        r.progress = Math.min(100, Math.round(total * 100f / goal));
        r.refresh = Math.max(now + 60000L, next);
        return r;
    }

    static String catLabel(JSONObject d, String cat) {
        JSONArray cs = d.optJSONArray("cats");
        if (cs != null) for (int i = 0; i < cs.length(); i++) { JSONObject c = cs.optJSONObject(i); if (c != null && cat.equals(c.optString("id"))) return c.optString("l", cat); }
        return "Bezig";
    }

    static String catColor(JSONObject d, String cat) {
        JSONArray cs = d.optJSONArray("cats");
        if (cs != null) for (int i = 0; i < cs.length(); i++) { JSONObject c = cs.optJSONObject(i); if (c != null && cat.equals(c.optString("id"))) return c.optString("c", "#8B7CF6"); }
        return "#8B7CF6";
    }

    /** Het vak Wat doe je nu: wat je nu doet, of de knop Ik ben wakker in de ochtend. */
    public static Now now(String dataJson, String ovJson, long now, long today0) {
        Now n = new Now();
        JSONObject d = obj(dataJson), ov = obj(ovJson);
        long at = d.optLong("at", 0);
        String cat = null, label = "", color = "#8B7CF6";
        long s = 0, e = 0;
        JSONObject cur = d.optJSONObject("cur");
        if (cur != null) { cat = cur.optString("cat", ""); label = cur.optString("l", ""); color = cur.optString("c", color); s = cur.optLong("s", 0); e = cur.optLong("e", 0); if (cat.isEmpty()) cat = null; }
        JSONObject oa = ov.optJSONObject("act");
        if (oa != null && oa.optLong("ts", 0) > at) {
            String oc = oa.optString("cat", "");
            if (oc.isEmpty()) cat = null;
            else {
                cat = oc; s = oa.optLong("ts"); long du = oa.optLong("dur", 0); e = du > 0 ? s + du : 0;
                String ti = oa.optString("title", "");
                label = ti.isEmpty() ? catLabel(d, oc) : ti; color = catColor(d, oc);
            }
        }
        if (cat != null && e > 0 && e <= now) cat = null;
        boolean wakeTapped = ov.optLong("wake", 0) > Math.max(at, today0);
        JSONObject wk = d.optJSONObject("wake");
        int hr = hourOf(now);
        boolean wake = !wakeTapped && wk != null && wk.optBoolean("need", false) && hr >= 4 && hr < 13;
        if (wake && (cat == null || s < today0 + 4 * 3600000L)) {
            n.title = "Goedemorgen"; n.sub = "Tik als je wakker bent, dan klopt je slaap"; n.btn = "Ik ben wakker"; n.mode = "wake"; n.cat = ""; n.color = "#9D91F8";
            return n;
        }
        if (cat != null) {
            n.title = label.isEmpty() ? catLabel(d, cat) : label; n.cat = cat; n.color = color; n.btn = "Klaar"; n.mode = "stop";
            if (e > 0) { n.sub = "Nog " + dur(e - now) + ", staat in je agenda"; n.refresh = e; }
            else n.sub = "Sinds " + hm(s) + ", staat in je agenda";
            return n;
        }
        String plan = d.optString("plan", "");
        n.sub = plan.isEmpty() ? "Tik erop, dan komt het in je agenda" : "Volgens je agenda: " + plan;
        return n;
    }

    /** De open habits, met wat je net op de widget hebt aangetikt erbij. */
    public static List<Habit> habits(String dataJson, String ovJson) {
        List<Habit> out = new ArrayList<>();
        JSONObject d = obj(dataJson), ov = obj(ovJson);
        long at = d.optLong("at", 0);
        JSONArray hs = d.optJSONArray("habits");
        JSONObject oh = ov.optJSONObject("h");
        if (hs == null) return out;
        for (int i = 0; i < hs.length(); i++) {
            JSONObject o = hs.optJSONObject(i);
            if (o == null) continue;
            Habit h = new Habit();
            h.id = o.optString("id", ""); h.icon = o.optString("i", ""); h.name = o.optString("n", "Habit"); h.color = o.optString("c", "#8B7CF6");
            h.mode = o.optString("m", "tap"); h.sub = o.optString("sub", "");
            int taps = 0;
            JSONArray ts = oh == null ? null : oh.optJSONArray(h.id);
            if (ts != null) for (int j = 0; j < ts.length(); j++) if (ts.optLong(j, 0) > at) taps++;
            if ("plus".equals(h.mode)) {
                int v = o.optInt("v", 0) + taps, t = Math.max(1, o.optInt("t", 1));
                h.done = v >= t; h.sub = Math.min(v, t) + " van " + t; h.btn = h.done ? "\u2713" : "+1";
            } else if ("open".equals(h.mode)) {
                h.btn = "\u203a"; h.sub = h.sub + " \u203a";
            } else {
                h.done = taps > 0; if (h.done) h.sub = "Gedaan"; h.btn = h.done ? "\u2713" : "";
            }
            out.add(h);
        }
        return out;
    }

    public static String countText(List<Habit> hs) {
        int open = 0;
        for (Habit h : hs) if (!h.done) open++;
        if (hs.isEmpty() || open == 0) return "Alles gedaan";
        return open + " open";
    }

    public static String stepsText(String dataJson) {
        JSONObject st = obj(dataJson).optJSONObject("steps");
        if (st == null) return "";
        return "Stappen: " + nf(st.optInt("v", 0)) + " van " + nf(Math.max(1, st.optInt("goal", 10000)));
    }

    public static int stepsPct(String dataJson) {
        JSONObject st = obj(dataJson).optJSONObject("steps");
        if (st == null) return 0;
        return Math.min(100, Math.round(st.optInt("v", 0) * 100f / Math.max(1, st.optInt("goal", 10000))));
    }

    /** Hoogte die elke versie nodig heeft, in dp: klein 152, half scherm 330, heel scherm 402 plus de tegels. */
    public static final int NEED_MID = 330, BASE_BIG = 402, TILE = 56, GAP = 8;

    /** Welke versie past zonder dat er iets wegvalt: 0 klein, 1 half scherm, 2 heel scherm. */
    public static int sizeKind(float hDp) { return hDp < NEED_MID ? 0 : (hDp < BASE_BIG + TILE + 9 ? 1 : 2); }

    /** Aantal rijen met twee habit-tegels dat past (1 tot 4). */
    public static int tileRows(float hDp) { return Math.max(1, Math.min(4, (int) Math.floor((hDp - BASE_BIG + GAP) / (float) (TILE + GAP)))); }

    /** Smal: dan alleen het microfoon-icoon en +250 zonder ml. */
    public static boolean narrow(float wDp) { return wDp > 0 && wDp < 300; }
}
