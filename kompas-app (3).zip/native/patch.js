// Voegt na "npx cap sync android" de eigen Android-code van Kompas toe.
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..'), android = path.join(root, 'android');
if (!fs.existsSync(android)) { console.log('Kompas: nog geen android-map, overslaan'); process.exit(0); }
const javaDir = path.join(android, 'app', 'src', 'main', 'java', 'nl', 'nielskonings', 'kompas');
fs.mkdirSync(javaDir, { recursive: true });
['KompasNativePlugin.java', 'MainActivity.java', 'KompasWidget.java', 'KompasWidgetText.java'].forEach(f => fs.copyFileSync(path.join(__dirname, f), path.join(javaDir, f)));
// widget: layout, achtergronden en info naar res kopieren
const resSrc = path.join(__dirname, 'res'), resDst = path.join(android, 'app', 'src', 'main', 'res');
const copyDir = (a, b) => { if (!fs.existsSync(a)) return; fs.mkdirSync(b, { recursive: true }); fs.readdirSync(a).forEach(n => { const s = path.join(a, n), d = path.join(b, n); if (fs.statSync(s).isDirectory()) copyDir(s, d); else fs.copyFileSync(s, d); }); };
copyDir(resSrc, resDst);
const mf = path.join(android, 'app', 'src', 'main', 'AndroidManifest.xml');
let xml = fs.readFileSync(mf, 'utf8');
if ((xml.indexOf('android.intent.category.LAUNCHER" /></intent>') < 0 || xml.indexOf('android.permission.WRITE_CALENDAR') < 0 || xml.indexOf('android.speech.RecognitionService') < 0) && xml.indexOf('<queries>') >= 0) {
  xml = xml.replace(/<queries>[\s\S]*?<\/queries>\s*/, '').replace(/\s*<uses-permission android:name="com\.android\.alarm\.permission\.SET_ALARM" \/>/, '');
}
if (xml.indexOf('com.android.alarm.permission.SET_ALARM') < 0) {
  const add = [
    '    <uses-permission android:name="com.android.alarm.permission.SET_ALARM" />',
    '    <uses-permission android:name="android.permission.READ_CALENDAR" />',
    '    <uses-permission android:name="android.permission.WRITE_CALENDAR" />',
    '    <queries>',
    '        <package android:name="nl.nos.app" />',
    '        <package android:name="digifit.virtuagym.foodtracker" />',
    '        <package android:name="com.sec.android.app.clockpackage" />',
    '        <intent><action android:name="android.intent.action.SET_ALARM" /></intent>',
    '        <intent><action android:name="android.intent.action.VIEW" /><category android:name="android.intent.category.BROWSABLE" /><data android:scheme="https" /></intent>',
    '        <intent><action android:name="android.intent.action.MAIN" /><category android:name="android.intent.category.LAUNCHER" /></intent>',
    '        <package android:name="com.google.android.apps.maps" />',
    '        <package android:name="com.waze" />',
    '        <package android:name="md.obsidian" />',
    '        <package android:name="com.whatsapp" />',
    '        <intent><action android:name="android.speech.RecognitionService" /></intent>',
    '        <intent><action android:name="android.intent.action.DIAL" /></intent>',
    '    </queries>'
  ].join('\n');
  xml = xml.replace(/<\/manifest>\s*$/, add + '\n</manifest>\n');
  fs.writeFileSync(mf, xml);
}
{ let mx = fs.readFileSync(mf, 'utf8');
  if (mx.indexOf('.KompasWidget') < 0 && mx.indexOf('</application>') >= 0) {
    const rc = ['        <receiver android:name=".KompasWidget" android:exported="true" android:label="Kompas">',
      '            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE" /></intent-filter>',
      '            <meta-data android:name="android.appwidget.provider" android:resource="@xml/kompas_widget_info" />',
      '        </receiver>'].join('\n');
    mx = mx.replace('</application>', rc + '\n    </application>');
    fs.writeFileSync(mf, mx);
  } }
const drawable = path.join(android, 'app', 'src', 'main', 'res', 'drawable');
fs.mkdirSync(drawable, { recursive: true });
fs.writeFileSync(path.join(drawable, 'ic_stat_kompas.xml'), [
  '<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">',
  '  <path android:fillColor="#FFFFFFFF" android:pathData="M12,2A10,10 0,1 0,22 12A10,10 0,0 0,12 2ZM12,4A8,8 0,1 1,4 12A8,8 0,0 1,12 4Z"/>',
  '  <path android:fillColor="#FFFFFFFF" android:pathData="M16.2,7.8L13.6,13.6L7.8,16.2L10.4,10.4Z"/>',
  '</vector>'].join('\n'));
const vars = path.join(android, 'variables.gradle');
if (fs.existsSync(vars)) {
  let g = fs.readFileSync(vars, 'utf8');
  g = g.replace(/minSdkVersion\s*=\s*\d+/, 'minSdkVersion = 26');
  if (g.indexOf('kotlin_version') < 0) g = g.replace(/ext\s*\{/, "ext {\n    kotlin_version = '2.4.20'");
  fs.writeFileSync(vars, g);
}
console.log('Kompas: eigen Android-code toegevoegd');
