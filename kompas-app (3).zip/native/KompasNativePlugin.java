package nl.nielskonings.kompas;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.provider.CalendarContract;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.provider.AlarmClock;
import android.util.Base64;
import com.getcapacitor.JSArray;
import com.getcapacitor.PermissionState;
import com.getcapacitor.JSObject;
import java.io.ByteArrayOutputStream;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

@CapacitorPlugin(
    name = "KompasNative",
    permissions = {
        @Permission(strings = { Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR }, alias = "calendar")
    }
)
public class KompasNativePlugin extends Plugin {

    private boolean tryStart(Intent intent) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            return true;
        } catch (ActivityNotFoundException e) {
            return false;
        } catch (SecurityException e) {
            return false;
        }
    }

    private static boolean empty(String s) {
        return s == null || s.isEmpty();
    }

    /** Bewaart waarmee de app vanuit de widget is geopend, zodat Kompas dat bij openen kan doen. */
    public static void storeLaunch(Context ctx, Intent intent) {
        if (ctx == null || intent == null) return;
        String a = intent.getStringExtra("kompas_action");
        if (a == null || a.isEmpty()) return;
        ctx.getSharedPreferences(KompasWidget.PREFS, Context.MODE_PRIVATE).edit()
            .putString("launch", a).putLong("launch_ts", System.currentTimeMillis()).apply();
        intent.removeExtra("kompas_action");
    }

    @PluginMethod
    public void updateWidget(PluginCall call) {
        Context ctx = getContext();
        String data = call.getString("data", "{}");
        ctx.getSharedPreferences(KompasWidget.PREFS, Context.MODE_PRIVATE).edit().putString("data", data).apply();
        // wat op de widget is aangetikt staat nu in de gegevens van Kompas
        try {
            long at = new org.json.JSONObject(data).optLong("at", 0L);
            SharedPreferences p = ctx.getSharedPreferences(KompasWidget.PREFS, Context.MODE_PRIVATE);
            org.json.JSONObject ov = new org.json.JSONObject(p.getString("ov", "{}"));
            org.json.JSONObject a = ov.optJSONObject("act");
            if (a != null && a.optLong("ts", 0L) <= at) ov.remove("act");
            if (ov.optLong("wake", 0L) <= at) ov.remove("wake");
            p.edit().putString("ov", ov.toString()).apply();
        } catch (Exception e) {
            // niets
        }
        KompasWidget.renderAll(ctx);
        JSObject r = new JSObject();
        r.put("widgets", KompasWidget.count(ctx));
        call.resolve(r);
    }

    @PluginMethod
    public void widgetPending(PluginCall call) {
        SharedPreferences p = getContext().getSharedPreferences(KompasWidget.PREFS, Context.MODE_PRIVATE);
        JSObject r = new JSObject();
        r.put("pending", p.getString("pending", "[]"));
        String launch = p.getString("launch", "");
        long ts = p.getLong("launch_ts", 0L);
        if (launch != null && !launch.isEmpty() && System.currentTimeMillis() - ts < 120000L) r.put("launch", launch);
        p.edit().putString("pending", "[]").remove("launch").remove("launch_ts").apply();
        r.put("widgets", KompasWidget.count(getContext()));
        call.resolve(r);
    }

    @PluginMethod
    public void openApp(PluginCall call) {
        String pkg = call.getString("package", "");
        String url = call.getString("url", "");
        String result = "none";
        if (!empty(pkg) && !empty(url)) {
            Intent view = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            view.setPackage(pkg);
            if (tryStart(view)) result = "app";
        }
        if (result.equals("none") && !empty(pkg) && empty(url)) {
            Intent launch = getContext().getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch != null && tryStart(launch)) result = "app";
        }
        if (result.equals("none") && !empty(url)) {
            Intent view = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            view.addCategory(Intent.CATEGORY_BROWSABLE);
            if (tryStart(view)) result = "link";
        }
        JSObject ret = new JSObject();
        ret.put("opened", result);
        call.resolve(ret);
    }

    @PluginMethod
    public void setAlarm(PluginCall call) {
        int hour = call.getInt("hour", 7);
        int minutes = call.getInt("minutes", 0);
        String message = call.getString("message", "Kompas");
        String pkg = call.getString("package", "");
        Intent alarm = new Intent(AlarmClock.ACTION_SET_ALARM);
        alarm.putExtra(AlarmClock.EXTRA_HOUR, hour);
        alarm.putExtra(AlarmClock.EXTRA_MINUTES, minutes);
        alarm.putExtra(AlarmClock.EXTRA_MESSAGE, message);
        alarm.putExtra(AlarmClock.EXTRA_SKIP_UI, false);
        if (!empty(pkg)) {
            Intent own = new Intent(alarm);
            own.setPackage(pkg);
            if (tryStart(own)) {
                call.resolve();
                return;
            }
        }
        if (tryStart(alarm)) {
            call.resolve();
        } else {
            call.reject("Geen wekker-app gevonden");
        }
    }

    private String iconData(Drawable d, int size) {
        Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        d.setBounds(0, 0, size, size);
        d.draw(canvas);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    @PluginMethod
    public void listApps(PluginCall call) {
        int size = call.getInt("iconSize", 72);
        boolean withIcons = call.getBoolean("icons", true);
        PackageManager pm = getContext().getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN, null);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = pm.queryIntentActivities(main, 0);
        Set<String> seen = new HashSet<>();
        String own = getContext().getPackageName();
        JSArray apps = new JSArray();
        for (ResolveInfo ri : found) {
            if (ri.activityInfo == null) continue;
            String pkg = ri.activityInfo.packageName;
            if (pkg == null || pkg.equals(own) || seen.contains(pkg)) continue;
            seen.add(pkg);
            JSObject o = new JSObject();
            o.put("package", pkg);
            o.put("label", String.valueOf(ri.loadLabel(pm)));
            if (withIcons) {
                try { o.put("icon", iconData(ri.loadIcon(pm), size)); } catch (Exception e) { o.put("icon", ""); }
            }
            apps.put(o);
        }
        JSObject ret = new JSObject();
        ret.put("apps", apps);
        call.resolve(ret);
    }

    private String calState() {
        PermissionState st = getPermissionState("calendar");
        if (st == PermissionState.GRANTED) return "granted";
        if (st == PermissionState.DENIED) return "denied";
        return "prompt";
    }

    @PluginMethod
    public void calendarPermission(PluginCall call) {
        boolean request = call.getBoolean("request", false);
        if (!request || "granted".equals(calState())) {
            JSObject r = new JSObject();
            r.put("calendar", calState());
            call.resolve(r);
            return;
        }
        requestPermissionForAlias("calendar", call, "calendarPermCallback");
    }

    @PermissionCallback
    private void calendarPermCallback(PluginCall call) {
        JSObject r = new JSObject();
        r.put("calendar", calState());
        call.resolve(r);
    }

    @PluginMethod
    public void listCalendars(PluginCall call) {
        if (!"granted".equals(calState())) { call.reject("Geen toestemming voor de agenda"); return; }
        String[] proj = {
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,
            CalendarContract.Calendars.ACCOUNT_NAME,
            CalendarContract.Calendars.ACCOUNT_TYPE,
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL,
            CalendarContract.Calendars.CALENDAR_COLOR,
            CalendarContract.Calendars.VISIBLE
        };
        JSArray arr = new JSArray();
        Cursor c = null;
        try {
            c = getContext().getContentResolver().query(CalendarContract.Calendars.CONTENT_URI, proj, null, null, null);
            while (c != null && c.moveToNext()) {
                JSObject o = new JSObject();
                o.put("id", String.valueOf(c.getLong(0)));
                o.put("name", c.getString(1));
                o.put("account", c.getString(2));
                o.put("type", c.getString(3));
                o.put("access", c.getInt(4));
                o.put("color", c.getInt(5));
                o.put("visible", c.getInt(6) == 1);
                arr.put(o);
            }
        } catch (Exception e) {
            call.reject("Agenda's lezen lukte niet: " + e.getMessage());
            return;
        } finally {
            if (c != null) c.close();
        }
        JSObject ret = new JSObject();
        ret.put("calendars", arr);
        call.resolve(ret);
    }

    private boolean eventAlive(ContentResolver cr, long id) {
        Cursor c = null;
        try {
            c = cr.query(CalendarContract.Events.CONTENT_URI,
                new String[] { CalendarContract.Events._ID, CalendarContract.Events.DELETED },
                CalendarContract.Events._ID + "=?", new String[] { String.valueOf(id) }, null);
            return c != null && c.moveToFirst() && c.getInt(1) == 0;
        } catch (Exception e) {
            return false;
        } finally {
            if (c != null) c.close();
        }
    }

    @PluginMethod
    public void upsertEvent(PluginCall call) {
        if (!"granted".equals(calState())) { call.reject("Geen toestemming voor de agenda"); return; }
        String calId = call.getString("calId", "");
        String pid = call.getString("eventId", "");
        if (empty(calId)) { call.reject("Geen agenda gekozen"); return; }
        long start = (long) (double) call.getDouble("start", 0.0);
        long end = (long) (double) call.getDouble("end", 0.0);
        boolean allDay = call.getBoolean("allDay", false);
        ContentValues v = new ContentValues();
        v.put(CalendarContract.Events.CALENDAR_ID, Long.parseLong(calId));
        v.put(CalendarContract.Events.TITLE, call.getString("title", ""));
        v.put(CalendarContract.Events.DESCRIPTION, call.getString("description", ""));
        v.put(CalendarContract.Events.EVENT_LOCATION, call.getString("location", ""));
        v.put(CalendarContract.Events.DTSTART, start);
        v.put(CalendarContract.Events.DTEND, end);
        v.put(CalendarContract.Events.ALL_DAY, allDay ? 1 : 0);
        v.put(CalendarContract.Events.EVENT_TIMEZONE, allDay ? "UTC" : call.getString("tz", "Europe/Amsterdam"));
        ContentResolver cr = getContext().getContentResolver();
        String outId = null;
        try {
            if (!empty(pid)) {
                long id = Long.parseLong(pid);
                if (eventAlive(cr, id)) {
                    int n = cr.update(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, id), v, null, null);
                    if (n > 0) outId = pid;
                }
            }
            if (outId == null) {
                Uri u = cr.insert(CalendarContract.Events.CONTENT_URI, v);
                if (u != null) outId = u.getLastPathSegment();
            }
        } catch (Exception e) {
            call.reject("Opslaan in je agenda lukte niet: " + e.getMessage());
            return;
        }
        if (outId == null) { call.reject("Opslaan in je agenda lukte niet"); return; }
        JSObject r = new JSObject();
        r.put("eventId", outId);
        call.resolve(r);
    }

    @PluginMethod
    public void deleteEvent(PluginCall call) {
        if (!"granted".equals(calState())) { call.reject("Geen toestemming voor de agenda"); return; }
        String pid = call.getString("eventId", "");
        int n = 0;
        try {
            if (!empty(pid)) n = getContext().getContentResolver().delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, Long.parseLong(pid)), null, null);
        } catch (Exception e) {
            call.reject("Weghalen uit je agenda lukte niet: " + e.getMessage());
            return;
        }
        JSObject r = new JSObject();
        r.put("deleted", n > 0);
        call.resolve(r);
    }

    @PluginMethod
    public void readEvents(PluginCall call) {
        if (!"granted".equals(calState())) { call.reject("Geen toestemming voor de agenda"); return; }
        long from = (long) (double) call.getDouble("from", 0.0);
        long to = (long) (double) call.getDouble("to", 0.0);
        Uri.Builder b = CalendarContract.Instances.CONTENT_URI.buildUpon();
        ContentUris.appendId(b, from);
        ContentUris.appendId(b, to);
        String[] proj = {
            CalendarContract.Instances.EVENT_ID,
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END,
            CalendarContract.Instances.ALL_DAY,
            CalendarContract.Instances.CALENDAR_ID,
            CalendarContract.Instances.CALENDAR_DISPLAY_NAME,
            CalendarContract.Instances.EVENT_LOCATION
        };
        JSArray arr = new JSArray();
        Cursor c = null;
        try {
            c = getContext().getContentResolver().query(b.build(), proj, null, null, CalendarContract.Instances.BEGIN + " ASC");
            int n = 0;
            while (c != null && c.moveToNext() && n < 4000) {
                n++;
                JSObject o = new JSObject();
                o.put("eventId", String.valueOf(c.getLong(0)));
                o.put("title", c.getString(1));
                o.put("begin", c.getLong(2));
                o.put("end", c.getLong(3));
                o.put("allDay", c.getInt(4) == 1);
                o.put("calId", String.valueOf(c.getLong(5)));
                o.put("calName", c.getString(6));
                o.put("location", c.getString(7));
                arr.put(o);
            }
        } catch (Exception e) {
            call.reject("Agenda lezen lukte niet: " + e.getMessage());
            return;
        } finally {
            if (c != null) c.close();
        }
        JSObject ret = new JSObject();
        ret.put("events", arr);
        call.resolve(ret);
    }
}
