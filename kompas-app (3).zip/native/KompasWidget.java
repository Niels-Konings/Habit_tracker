package nl.nielskonings.kompas;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.SizeF;
import android.view.View;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Widget op het startscherm, klein, half of heel scherm. */
public class KompasWidget extends AppWidgetProvider {
    public static final String PREFS = "kompas_widget";
    public static final String ACTION_WATER = "nl.nielskonings.kompas.WIDGET_WATER";
    public static final String ACTION_TICK = "nl.nielskonings.kompas.WIDGET_TICK";
    public static final String ACTION_ACT = "nl.nielskonings.kompas.WIDGET_ACT";
    public static final String ACTION_STOP = "nl.nielskonings.kompas.WIDGET_STOP";
    public static final String ACTION_WAKE = "nl.nielskonings.kompas.WIDGET_WAKE";
    public static final String ACTION_HABIT = "nl.nielskonings.kompas.WIDGET_HABIT";
    private static final Locale NL = new Locale("nl", "NL");
    private static final String[] CHIP_CATS = {"studie", "werk", "sport", "eten", "reizen", "overig"};

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) { renderAll(ctx); }

    @Override
    public void onAppWidgetOptionsChanged(Context ctx, AppWidgetManager mgr, int id, Bundle opts) { renderAll(ctx); }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        super.onReceive(ctx, intent);
        String a = intent == null ? null : intent.getAction();
        if (a == null) return;
        long ts = System.currentTimeMillis();
        try {
            if (ACTION_WATER.equals(a)) {
                JSONObject o = new JSONObject(); o.put("ml", intent.getIntExtra("ml", 250)); o.put("ts", ts); addPending(ctx, o);
            } else if (ACTION_ACT.equals(a)) {
                String cat = intent.getStringExtra("cat"); if (cat == null || cat.isEmpty()) return;
                JSONObject o = new JSONObject(); o.put("t", "act"); o.put("cat", cat); o.put("ts", ts); addPending(ctx, o);
                JSONObject ov = new JSONObject(); ov.put("cat", cat); ov.put("ts", ts); setOverride(ctx, "act", ov);
            } else if (ACTION_STOP.equals(a)) {
                JSONObject o = new JSONObject(); o.put("t", "stop"); o.put("ts", ts); addPending(ctx, o);
                JSONObject ov = new JSONObject(); ov.put("cat", ""); ov.put("ts", ts); setOverride(ctx, "act", ov);
            } else if (ACTION_WAKE.equals(a)) {
                JSONObject o = new JSONObject(); o.put("t", "wake"); o.put("ts", ts); addPending(ctx, o);
                JSONObject ov = new JSONObject(); ov.put("cat", "overig"); ov.put("ts", ts); ov.put("dur", 600000L); ov.put("title", "Opstaan en verzorging");
                setOverride(ctx, "act", ov); setOverride(ctx, "wake", ts);
            } else if (ACTION_HABIT.equals(a)) {
                String id = intent.getStringExtra("id"); if (id == null || id.isEmpty()) return;
                JSONObject o = new JSONObject(); o.put("t", "habit"); o.put("id", id); o.put("ts", ts); addPending(ctx, o);
                addHabitTap(ctx, id, ts);
            } else if (!ACTION_TICK.equals(a)) {
                return;
            }
        } catch (Exception e) {
            return;
        }
        renderAll(ctx);
    }

    @Override
    public void onDisabled(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(broadcast(ctx, ACTION_TICK, 21, null, null));
    }

    public static int count(Context ctx) {
        int[] ids = AppWidgetManager.getInstance(ctx).getAppWidgetIds(new ComponentName(ctx, KompasWidget.class));
        return ids == null ? 0 : ids.length;
    }

    static SharedPreferences prefs(Context ctx) { return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    static void addPending(Context ctx, JSONObject o) throws Exception {
        SharedPreferences p = prefs(ctx);
        JSONArray pend = new JSONArray(p.getString("pending", "[]"));
        pend.put(o);
        p.edit().putString("pending", pend.toString()).apply();
    }

    static void setOverride(Context ctx, String key, Object val) throws Exception {
        SharedPreferences p = prefs(ctx);
        JSONObject ov = new JSONObject(p.getString("ov", "{}"));
        ov.put(key, val);
        p.edit().putString("ov", ov.toString()).apply();
    }

    static void addHabitTap(Context ctx, String id, long ts) throws Exception {
        SharedPreferences p = prefs(ctx);
        JSONObject ov = new JSONObject(p.getString("ov", "{}"));
        JSONObject h = ov.optJSONObject("h"); if (h == null) h = new JSONObject();
        JSONArray l = h.optJSONArray(id); if (l == null) l = new JSONArray();
        l.put(ts); h.put(id, l); ov.put("h", h);
        p.edit().putString("ov", ov.toString()).apply();
    }

    static String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }

    static long startOfToday() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    static int color(String hex, int fallback) { try { return Color.parseColor(hex); } catch (Exception e) { return fallback; } }

    static PendingIntent openIntent(Context ctx, String action, int code) {
        Intent i = new Intent(ctx, MainActivity.class);
        i.setAction("nl.nielskonings.kompas.OPEN_" + code);
        i.putExtra("kompas_action", action);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static PendingIntent broadcast(Context ctx, String action, int code, String key, String val) {
        Intent i = new Intent(ctx, KompasWidget.class);
        i.setAction(action);
        if (key != null) i.putExtra(key, val);
        if (ACTION_WATER.equals(action)) i.putExtra("ml", 250);
        return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void renderAll(Context ctx) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, KompasWidget.class));
        if (ids == null || ids.length == 0) return;
        long[] next = {System.currentTimeMillis() + 3600000L};
        for (int id : ids) {
            RemoteViews rv;
            try {
                Bundle o = mgr.getAppWidgetOptions(id);
                ArrayList<SizeF> sizes = null;
                if (Build.VERSION.SDK_INT >= 31 && o != null) sizes = o.getParcelableArrayList(AppWidgetManager.OPTION_APPWIDGET_SIZES);
                if (Build.VERSION.SDK_INT >= 31 && sizes != null && !sizes.isEmpty()) {
                    Map<SizeF, RemoteViews> m = new HashMap<>();
                    for (SizeF s : sizes) if (m.size() < 12) m.put(s, build(ctx, s.getWidth(), s.getHeight(), next));
                    rv = new RemoteViews(m);
                } else {
                    int h = o == null ? 160 : o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 160);
                    int wd = o == null ? 360 : o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 360);
                    rv = build(ctx, wd, h, next);
                }
            } catch (Exception e) {
                rv = build(ctx, 360, 160, next);
            }
            mgr.updateAppWidget(id, rv);
        }
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.set(AlarmManager.RTC, Math.max(System.currentTimeMillis() + 60000L, next[0]), broadcast(ctx, ACTION_TICK, 21, null, null));
    }

    static RemoteViews build(Context ctx, float wDp, float hDp, long[] next) {
        int kind = KompasWidgetText.sizeKind(hDp);
        int layout = kind == 0 ? R.layout.kompas_widget : (kind == 1 ? R.layout.kompas_widget_mid : R.layout.kompas_widget_big);
        RemoteViews v = new RemoteViews(ctx.getPackageName(), layout);
        SharedPreferences p = prefs(ctx);
        String data = p.getString("data", "{}"), pend = p.getString("pending", "[]"), ov = p.getString("ov", "{}");
        long now = System.currentTimeMillis(), t0 = startOfToday();
        try {
            KompasWidgetText.Result r = KompasWidgetText.compute(data, pend, now, t0, today());
            next[0] = Math.min(next[0], r.refresh);
            String dateShort = new SimpleDateFormat("EEE d MMM", NL).format(new Date(now)).replace(".", "");
            v.setTextViewText(R.id.kw_wtext, r.water);
            v.setProgressBar(R.id.kw_wbar, 100, r.progress, false);
            if (kind == 0) {
                v.setTextViewText(R.id.kw_date, KompasWidgetText.cap(dateShort));
                v.setTextViewText(R.id.kw_over, r.over);
                v.setTextViewText(R.id.kw_title, r.title);
                v.setTextViewText(R.id.kw_sub, r.sub);
                v.setOnClickPendingIntent(R.id.kw_main, openIntent(ctx, "agenda", 11));
            } else {
                String dateLong = KompasWidgetText.cap(new SimpleDateFormat("EEEE d MMMM", NL).format(new Date(now)));
                v.setTextViewText(R.id.kw_date, dateLong);
                v.setTextViewText(R.id.kw_next, r.next);
                v.setOnClickPendingIntent(R.id.kw_head, openIntent(ctx, "agenda", 11));
                v.setOnClickPendingIntent(R.id.kw_open, openIntent(ctx, "open", 10));
                fillNow(ctx, v, data, ov, now, t0, next);
                if (kind == 2) fillTiles(ctx, v, data, ov, KompasWidgetText.tileRows(hDp));
            }
        } catch (Exception e) {
            if (kind == 0) { v.setTextViewText(R.id.kw_title, "Open Kompas"); v.setTextViewText(R.id.kw_sub, "Tik om bij te werken"); }
        }
        if (KompasWidgetText.narrow(wDp)) { v.setViewVisibility(R.id.kw_mic_t, View.GONE); v.setTextViewText(R.id.kw_add, "+250"); }
        v.setOnClickPendingIntent(R.id.kw_root, openIntent(ctx, "open", 10));
        v.setOnClickPendingIntent(R.id.kw_water, openIntent(ctx, "habits", 12));
        v.setOnClickPendingIntent(R.id.kw_add, broadcast(ctx, ACTION_WATER, 20, null, null));
        v.setOnClickPendingIntent(R.id.kw_mic, openIntent(ctx, "journal", 13));
        return v;
    }

    static final int[] CHIP = {R.id.kw_c0, R.id.kw_c1, R.id.kw_c2, R.id.kw_c3, R.id.kw_c4, R.id.kw_c5};
    static final int[] CHIP_DOT = {R.id.kw_c0_dot, R.id.kw_c1_dot, R.id.kw_c2_dot, R.id.kw_c3_dot, R.id.kw_c4_dot, R.id.kw_c5_dot};
    static final int[] CHIP_T = {R.id.kw_c0_t, R.id.kw_c1_t, R.id.kw_c2_t, R.id.kw_c3_t, R.id.kw_c4_t, R.id.kw_c5_t};

    static int chipOn(String cat) {
        switch (cat) {
            case "studie": return R.drawable.kw_chip_on_studie;
            case "werk": return R.drawable.kw_chip_on_werk;
            case "sport": return R.drawable.kw_chip_on_sport;
            case "eten": return R.drawable.kw_chip_on_eten;
            case "reizen": return R.drawable.kw_chip_on_reizen;
            case "overig": return R.drawable.kw_chip_on_overig;
            default: return R.drawable.kw_chip_on;
        }
    }

    static void fillNow(Context ctx, RemoteViews v, String data, String ov, long now, long t0, long[] next) throws Exception {
        KompasWidgetText.Now n = KompasWidgetText.now(data, ov, now, t0);
        if (n.refresh > now) next[0] = Math.min(next[0], n.refresh);
        v.setTextViewText(R.id.kw_nu_title, n.title);
        v.setTextViewText(R.id.kw_nu_sub, n.sub);
        v.setInt(R.id.kw_nu_dot, "setColorFilter", color(n.color, 0xFF3A4255));
        if (n.btn.isEmpty()) {
            v.setViewVisibility(R.id.kw_nu_btn, View.GONE);
        } else {
            v.setViewVisibility(R.id.kw_nu_btn, View.VISIBLE);
            v.setTextViewText(R.id.kw_nu_btn, n.btn);
            boolean wake = "wake".equals(n.mode);
            v.setInt(R.id.kw_nu_btn, "setBackgroundResource", wake ? R.drawable.kw_btn_accent : R.drawable.kw_btn_outline);
            v.setTextColor(R.id.kw_nu_btn, 0xFFFFFFFF);
            v.setOnClickPendingIntent(R.id.kw_nu_btn, broadcast(ctx, wake ? ACTION_WAKE : ACTION_STOP, wake ? 41 : 40, null, null));
        }
        JSONObject d = new JSONObject(data);
        JSONArray cats = d.optJSONArray("cats");
        for (int i = 0; i < 6; i++) {
            String cat = CHIP_CATS[i], label = KompasWidgetText.catLabel(d, cat), col = KompasWidgetText.catColor(d, cat);
            if (cats == null) { label = new String[]{"Studie", "Werk", "Sporten", "Eten", "Onderweg", "Vrije tijd"}[i]; col = new String[]{"#5B8DEF", "#F6A94A", "#37C871", "#9FC93C", "#8E97A8", "#9AA5B8"}[i]; }
            v.setTextViewText(CHIP_T[i], label);
            v.setInt(CHIP_DOT[i], "setColorFilter", color(col, 0xFF8B7CF6));
            v.setInt(CHIP[i], "setBackgroundResource", cat.equals(n.cat) ? chipOn(cat) : R.drawable.kw_chip);
            v.setOnClickPendingIntent(CHIP[i], broadcast(ctx, ACTION_ACT, 30 + i, "cat", cat));
        }
    }

    static final int[] ROW = {R.id.kw_r0, R.id.kw_r1, R.id.kw_r2, R.id.kw_r3};
    static final int[] T = {R.id.kw_t0, R.id.kw_t1, R.id.kw_t2, R.id.kw_t3, R.id.kw_t4, R.id.kw_t5, R.id.kw_t6, R.id.kw_t7};
    static final int[] T_BG = {R.id.kw_t0_bg, R.id.kw_t1_bg, R.id.kw_t2_bg, R.id.kw_t3_bg, R.id.kw_t4_bg, R.id.kw_t5_bg, R.id.kw_t6_bg, R.id.kw_t7_bg};
    static final int[] T_ICON = {R.id.kw_t0_icon, R.id.kw_t1_icon, R.id.kw_t2_icon, R.id.kw_t3_icon, R.id.kw_t4_icon, R.id.kw_t5_icon, R.id.kw_t6_icon, R.id.kw_t7_icon};
    static final int[] T_NAME = {R.id.kw_t0_name, R.id.kw_t1_name, R.id.kw_t2_name, R.id.kw_t3_name, R.id.kw_t4_name, R.id.kw_t5_name, R.id.kw_t6_name, R.id.kw_t7_name};
    static final int[] T_SUB = {R.id.kw_t0_sub, R.id.kw_t1_sub, R.id.kw_t2_sub, R.id.kw_t3_sub, R.id.kw_t4_sub, R.id.kw_t5_sub, R.id.kw_t6_sub, R.id.kw_t7_sub};

    /** Habits als tegels, twee naast elkaar. */
    static void fillTiles(Context ctx, RemoteViews v, String data, String ov, int rows) {
        List<KompasWidgetText.Habit> hs = KompasWidgetText.habits(data, ov);
        v.setTextViewText(R.id.kw_h_count, KompasWidgetText.countText(hs));
        v.setViewVisibility(R.id.kw_h_empty, hs.isEmpty() ? View.VISIBLE : View.GONE);
        int shown = Math.min(hs.size(), rows * 2);
        for (int r = 0; r < 4; r++) v.setViewVisibility(ROW[r], r * 2 < shown ? View.VISIBLE : View.GONE);
        for (int i = 0; i < 8; i++) {
            if (i >= shown) { v.setViewVisibility(T[i], View.INVISIBLE); continue; }
            KompasWidgetText.Habit h = hs.get(i);
            v.setViewVisibility(T[i], View.VISIBLE);
            v.setTextViewText(T_ICON[i], h.done ? "\u2713" : h.icon);
            v.setInt(T_BG[i], "setColorFilter", color(h.color, 0xFF8B7CF6));
            v.setInt(T_BG[i], "setImageAlpha", h.done ? 255 : 46);
            v.setTextViewText(T_NAME[i], h.name);
            v.setTextColor(T_NAME[i], h.done ? 0xFF9AA2B4 : 0xFFE9EBF2);
            v.setTextViewText(T_SUB[i], h.sub);
            boolean part = "plus".equals(h.mode) && !h.done && !h.sub.startsWith("0 ");
            v.setInt(T[i], "setBackgroundResource", part ? R.drawable.kw_tilebox_part : R.drawable.kw_tilebox);
            if ("open".equals(h.mode)) v.setOnClickPendingIntent(T[i], openIntent(ctx, "habit:" + h.id, 60 + i));
            else v.setOnClickPendingIntent(T[i], broadcast(ctx, ACTION_HABIT, 50 + i, "id", h.id));
        }
        String st = KompasWidgetText.stepsText(data);
        if (st.isEmpty()) v.setViewVisibility(R.id.kw_steps, View.GONE);
        else {
            v.setViewVisibility(R.id.kw_steps, View.VISIBLE);
            v.setTextViewText(R.id.kw_steps_t, st);
            v.setProgressBar(R.id.kw_steps_bar, 100, KompasWidgetText.stepsPct(data), false);
        }
    }
}
