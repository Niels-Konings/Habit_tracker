package nl.nielskonings.kompas;

import android.content.Intent;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(KompasNativePlugin.class);
        super.onCreate(savedInstanceState);
        KompasNativePlugin.storeLaunch(this, getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        KompasNativePlugin.storeLaunch(this, intent);
    }
}
